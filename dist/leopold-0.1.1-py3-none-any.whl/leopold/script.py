from .leopold import cli
def run():
    cli()